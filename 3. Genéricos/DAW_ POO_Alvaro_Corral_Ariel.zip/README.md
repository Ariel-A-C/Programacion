El formato de los archivos entregados no es el que se pide en el enunciado porque es más simple así y porque el enunciado está mal (pide 2 veces el mismo .gif, que además no es necesario, basta con un .png).

En este caso es mejor usar ArrayList porque permite modificar (añadir/borrar) los elementos más fácilmente que un Array.

En cuanto a los ejercicios, el segundo ha sido más difícil y he sacado de internet líneas como `T firstItem = (T) array[0];` porque esa T es confusa o `System.arraycopy(array, 1, array, 0, size - 1);` que no sabía que existía.
import java.util.HashSet;

public class EX10 {
    public static void main(String[] args) {
        HashSet<String> hSet = new HashSet<String>();
        hSet.add("First");
        hSet.add("Second");
        hSet.add("Third");
        hSet.add("Fourth");
        hSet.add("Fifth");
        System.out.println(hSet);
    }
}